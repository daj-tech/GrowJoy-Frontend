const passwordInput = document.getElementById('password');
    const togglePassword = document.getElementById('togglePassword');
    const form = document.getElementById('loginForm');
    const formMessage = document.getElementById('formMessage');

    togglePassword.addEventListener('click', () => {
      const showPassword = passwordInput.type === 'password';
      passwordInput.type = showPassword ? 'text' : 'password';
      togglePassword.setAttribute('aria-label', showPassword ? 'Hide password' : 'Show password');
      togglePassword.setAttribute('aria-pressed', String(showPassword));
      togglePassword.classList.toggle('is-visible', showPassword);
    });

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      formMessage.textContent = 'Demo sign-in successful. Opening your dashboard…';
      window.location.href = '../dashboard/index.html';
    });

    document.getElementById('forgotLink').addEventListener('click', (event) => {
      event.preventDefault();
      formMessage.textContent = 'This review demo uses sample sign-in. Enter any email and password to continue.';
    });

    document.getElementById('createLink').addEventListener('click', (event) => {
      event.preventDefault();
      formMessage.textContent = 'Your demo GrowJoy space is ready. Opening the dashboard…';
      window.location.href = '../dashboard/index.html';
    });
