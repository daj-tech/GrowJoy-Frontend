const taskCheckboxes = [...document.querySelectorAll('.task-checkbox')];
    const completedCount = document.getElementById('completedCount');
    const taskCount = document.getElementById('taskCount');
    const dailyProgress = document.getElementById('dailyProgress');
    const toast = document.getElementById('toast');
    let toastTimer;

    function showToast(message) {
      toast.textContent = message;
      toast.classList.add('visible');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => toast.classList.remove('visible'), 2600);
    }

    const savedTasks = JSON.parse(localStorage.getItem('growjoyTasks') || '[]');
    taskCheckboxes.forEach((box, index) => { box.checked = Boolean(savedTasks[index]); });

    function updateTasks() {
      const completed = taskCheckboxes.filter(box => box.checked).length;
      localStorage.setItem('growjoyTasks', JSON.stringify(taskCheckboxes.map(box => box.checked)));
      completedCount.textContent = completed;
      taskCount.textContent = 3 - completed;
      dailyProgress.style.width = `${completed / taskCheckboxes.length * 100}%`;
      document.querySelectorAll('.care-task').forEach((task, index) => {
        task.classList.toggle('is-complete', taskCheckboxes[index].checked);
      });
      if (completed === taskCheckboxes.length) {
        showToast('Lovely work! You completed today’s sample care tasks.');
      }
    }
    taskCheckboxes.forEach(box => box.addEventListener('change', updateTasks));
    updateTasks();

    document.getElementById('continueButton').addEventListener('click', () => {
      window.location.href = '../activity/index.html';
    });
