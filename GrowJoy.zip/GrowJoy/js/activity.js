const photoInput = document.getElementById('photoInput');
    const choosePhoto = document.getElementById('choosePhoto');
    const uploadPreview = document.getElementById('uploadPreview');
    const previewImage = document.getElementById('previewImage');
    const previewName = document.getElementById('previewName');
    const uploadDescription = document.getElementById('uploadDescription');
    const photoStatus = document.getElementById('photoStatus');
    const photoTask = document.getElementById('photoTask');
const knownPlants = ['Mint', 'Lemon Balm', 'Parsley'];
const savedPlant = localStorage.getItem('growjoySelectedPlant');
const selectedPlant = knownPlants.includes(savedPlant) ? savedPlant : 'Mint';
document.title = `Plant Care Activities & Rewards | ${selectedPlant} | GrowJoy`;
document.querySelector('.intro-copy h1').innerHTML = `Let's Help Your ${selectedPlant} <span>Thrive!</span>`;
document.querySelector('.plant-identity strong').textContent = selectedPlant;
document.querySelector('.growth-heading h2').textContent = `Your ${selectedPlant}'s Growth`;
document.querySelector('.growth-plant-info h3').textContent = selectedPlant;
const lightByPlant = {
  'Mint': 'Make sure your mint receives bright, indirect light.',
  'Lemon Balm': 'Give your lemon balm bright, indirect light or partial shade.',
  'Parsley': 'Place your parsley where it receives plenty of bright light.'
};
document.querySelector('#lightTask .task-main p').textContent = lightByPlant[selectedPlant] || lightByPlant.Mint;
const plantArt = document.querySelector('.large-mint-illustration');
const potArt = '<path d="M122 180H238L223 225Q180 240 137 225Z" fill="#C9825C"/><path d="M117 176Q180 185 243 176L238 191Q180 199 122 191Z" fill="#DDA07B"/><ellipse cx="180" cy="178" rx="62" ry="9" fill="#704D36" opacity=".9"/><path d="M142 207Q180 216 218 207" fill="none" stroke="#E6B79A" stroke-width="2.5" opacity=".7"/>';
const plantArtByName = {
  'Lemon Balm': '<path d="M180 180C178 140 183 95 180 40M180 139L127 104M181 149L234 107M180 103L146 64M180 118L217 65M180 168L132 145" fill="none" stroke="#347B4B" stroke-width="4" stroke-linecap="round"/><g fill="#69A94F" stroke="#347B4B" stroke-width="1.5"><path d="M174 117C144 122 116 108 106 82C132 72 164 88 174 117Z"/><path d="M186 128C216 132 241 113 247 88C220 82 193 101 186 128Z"/><path d="M177 88C155 73 153 48 169 29C190 47 194 71 177 88Z"/><path d="M179 159C151 171 126 156 116 135C142 123 169 137 179 159Z"/><path d="M185 164C211 179 237 164 247 142C221 129 194 142 185 164Z"/></g><g fill="#88BF62" stroke="#347B4B" stroke-width="1.3"><path d="M177 122C148 140 119 129 103 109C127 94 161 101 177 122Z"/><path d="M184 99C210 104 236 87 243 63C218 57 192 77 184 99Z"/><path d="M181 78C163 57 170 37 184 23C202 43 199 64 181 78Z"/></g>' + potArt,
  'Parsley': '<path d="M180 180V58M180 117L132 82M180 126L229 86M180 91L151 55M180 100L209 54M180 151L138 126" fill="none" stroke="#347B4B" stroke-width="4" stroke-linecap="round"/><g fill="#398A49" stroke="#2E7742" stroke-width="1.4" stroke-linejoin="round"><path d="M176 93 159 80 164 66 149 61 157 47 145 36 165 30 177 45 189 33 201 46 194 60 209 66 198 81 184 75Z"/><path d="M176 120 154 114 151 102 136 103 130 90 144 82 157 90 169 82 181 98Z"/><path d="M185 119 196 103 210 103 214 89 229 94 230 108 218 116 207 111 196 126Z"/><path d="M175 153 156 147 150 134 164 126 177 133 185 125 199 133 192 148Z"/></g><g fill="#72B85B" stroke="#347B4B" stroke-width="1.2"><path d="M176 94 163 82 168 72 156 66 167 59 178 67 188 58 196 70 188 80 197 88 186 99Z"/><path d="M178 124 160 119 158 108 144 107 142 96 154 90 166 100 177 94 187 106Z"/><path d="M184 125 197 113 209 115 214 103 226 108 221 120 209 124 201 118 191 132Z"/></g>' + potArt
};
if (plantArtByName[selectedPlant]) {
  plantArt.innerHTML = plantArtByName[selectedPlant];
}
document.querySelector('.mint-hero-art').setAttribute('aria-label', `Healthy ${selectedPlant.toLowerCase()} plant illustration in a terracotta pot`);
document.querySelectorAll('.task-main p, #uploadDescription').forEach(text => {
  text.textContent = text.textContent.replace(/mint/gi, selectedPlant);
});
document.querySelector('.care-tip p').textContent = 'Check your plant’s care needs and soil before watering. A little attention to its light and moisture helps it grow well.';
    const toast = document.getElementById('toast');
    let toastTimer;
    let previewUrl = null;

    function showToast(message) {
      toast.textContent = message;
      toast.classList.add('visible');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => toast.classList.remove('visible'), 3200);
    }

    function openPhotoPicker() { photoInput.click(); }
    choosePhoto.addEventListener('click', openPhotoPicker);

    photoInput.addEventListener('change', () => {
      const file = photoInput.files && photoInput.files[0];
      if (!file) return;
      const allowed = ['image/jpeg', 'image/png', 'image/webp'];
      if (!allowed.includes(file.type)) {
        showToast('Please choose a JPG, PNG or WEBP image.');
        photoInput.value = '';
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        showToast('That image is over 10 MB. Please choose a smaller photo.');
        photoInput.value = '';
        return;
      }
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      previewUrl = URL.createObjectURL(file);
      previewImage.src = previewUrl;
      previewName.textContent = file.name;
      uploadPreview.hidden = false;
      uploadDescription.textContent = `Photo selected for ${selectedPlant}. Ready for submission.`;
      photoStatus.textContent = 'Awaiting Verification';
      photoStatus.className = 'status-badge awaiting';
      photoTask.classList.add('awaiting-review');
      choosePhoto.textContent = 'Change Photo';
      showToast('Photo selected. It is awaiting submission and verification; no coins have been awarded.');
    });

    document.getElementById('removePhoto').addEventListener('click', () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      previewUrl = null;
      photoInput.value = '';
      previewImage.removeAttribute('src');
      uploadPreview.hidden = true;
      uploadDescription.textContent = `Add a photo to record your ${selectedPlant}'s current growth.`;
      photoStatus.textContent = 'Photo Required';
      photoStatus.className = 'status-badge photo-required';
      photoTask.classList.remove('awaiting-review');
      choosePhoto.innerHTML = 'Choose Photo <span>＋</span>';
      showToast('Photo selection cleared.');
    });

    const lightComplete = document.getElementById('lightComplete');
    lightComplete.addEventListener('change', () => {
      const task = document.getElementById('lightTask');
      const status = task.querySelector('.status-badge');
      if (lightComplete.checked) {
        task.classList.add('task-complete');
        status.textContent = 'Completed';
        status.className = 'status-badge submitted';
        showToast('Light check marked complete in this demo. Connect verification before awarding Care Coins.');
      } else {
        task.classList.remove('task-complete');
        status.textContent = 'To Do';
        status.className = 'status-badge todo';
      }
      const questDone = document.getElementById('questDone');
      const completedQuests = lightComplete.checked ? 2 : 1;
      questDone.textContent = completedQuests;
      questDone.closest('.quest-count').setAttribute('aria-label', `${completedQuests} of 3 tasks complete`);
    });

    document.getElementById('viewJourney').addEventListener('click', () => {
      window.location.href = '../dashboard/index.html';
    });
