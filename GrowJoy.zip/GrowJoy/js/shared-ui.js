(() => {
  const profileButton = document.getElementById('profileButton');
  const notificationButton = document.getElementById('notificationButton');
  if (!profileButton || !notificationButton) return;

  const plantOptions = ['Mint', 'Lemon Balm', 'Parsley'];
  const storedPlant = localStorage.getItem('growjoySelectedPlant');
  const plant = plantOptions.includes(storedPlant) ? storedPlant : 'Mint';

  const profilePanel = document.createElement('section');
  profilePanel.className = 'floating-panel profile-panel';
  profilePanel.id = 'profilePanel';
  profilePanel.setAttribute('role', 'dialog');
  profilePanel.setAttribute('aria-label', 'GrowJoy profile');
  profilePanel.hidden = true;
  profilePanel.innerHTML = `
    <button class="panel-close" type="button" aria-label="Close profile panel">×</button>
    <span class="panel-eyebrow">YOUR GROWJOY SPACE</span>
    <h2>Welcome back, Grower</h2>
    <p>Your ${plant} journey is growing one small win at a time.</p>
    <div class="profile-links">
      <a class="profile-link" href="../dashboard/index.html">⌂ <span>Dashboard</span></a>
      <a class="profile-link" href="../activity/index.html">♧ <span>My plants</span></a>
      <a class="profile-link" href="../conditions/index.html">✦ <span>Growing preferences</span></a>
      <a class="profile-link" href="../home/index.html">↗ <span>Back to welcome page</span></a>
    </div>`;

  const notificationPanel = document.createElement('section');
  notificationPanel.className = 'floating-panel notification-panel';
  notificationPanel.id = 'notificationPanel';
  notificationPanel.setAttribute('role', 'dialog');
  notificationPanel.setAttribute('aria-label', 'GrowJoy notifications');
  notificationPanel.hidden = true;
  notificationPanel.innerHTML = `
    <button class="panel-close" type="button" aria-label="Close notifications">×</button>
    <span class="panel-eyebrow">A LITTLE CARE GOES A LONG WAY</span>
    <h2>Your garden notes</h2>
    <div class="panel-item"><span class="panel-dot" aria-hidden="true"></span><div><strong>Today's care quests are ready</strong><small>Give your ${plant} a quick check in My Plants.</small></div></div>
    <div class="panel-item"><span class="panel-dot" aria-hidden="true"></span><div><strong>Keep your growing streak alive</strong><small>Small, steady care helps your plant thrive.</small></div></div>
    <button class="panel-action" type="button">Open today's care quests <span aria-hidden="true">→</span></button>
    <button class="mark-read-button" type="button">Mark all as read</button>`;
  document.body.append(profilePanel, notificationPanel);

  profileButton.setAttribute('aria-haspopup', 'dialog');
  profileButton.setAttribute('aria-controls', profilePanel.id);
  profileButton.setAttribute('aria-expanded', 'false');
  notificationButton.setAttribute('aria-haspopup', 'dialog');
  notificationButton.setAttribute('aria-controls', notificationPanel.id);
  notificationButton.setAttribute('aria-expanded', 'false');
  const notificationDot = notificationButton.querySelector('.notification-dot');
  const markReadButton = notificationPanel.querySelector('.mark-read-button');
  const notificationsRead = localStorage.getItem('growjoyNotificationsRead') === 'true';
  notificationButton.setAttribute('aria-label', notificationsRead ? 'Notifications, all read' : 'Notifications, two unread');
  if (notificationsRead && notificationDot) notificationDot.hidden = true;
  if (notificationsRead) {
    markReadButton.textContent = 'All notifications read';
    markReadButton.disabled = true;
  }

  const panels = [profilePanel, notificationPanel];
  const triggers = [profileButton, notificationButton];
  function closePanels() {
    panels.forEach(panel => { panel.hidden = true; });
    triggers.forEach(trigger => trigger.setAttribute('aria-expanded', 'false'));
  }
  function togglePanel(panel, trigger) {
    const willOpen = panel.hidden;
    closePanels();
    if (willOpen) {
      panel.hidden = false;
      trigger.setAttribute('aria-expanded', 'true');
      panel.querySelector('.panel-close').focus();
    }
  }

  profileButton.addEventListener('click', () => togglePanel(profilePanel, profileButton));
  notificationButton.addEventListener('click', () => togglePanel(notificationPanel, notificationButton));
  profilePanel.querySelector('.panel-close').addEventListener('click', () => {
    closePanels(); profileButton.focus();
  });
  notificationPanel.querySelector('.panel-close').addEventListener('click', () => {
    closePanels(); notificationButton.focus();
  });
  notificationPanel.querySelector('.panel-action').addEventListener('click', () => {
    window.location.href = '../activity/index.html';
  });
  markReadButton.addEventListener('click', () => {
    localStorage.setItem('growjoyNotificationsRead', 'true');
    notificationButton.setAttribute('aria-label', 'Notifications, all read');
    if (notificationDot) notificationDot.hidden = true;
    markReadButton.textContent = 'All notifications read';
    markReadButton.disabled = true;
  });
  document.addEventListener('click', event => {
    if (!panels.some(panel => panel.contains(event.target)) && !triggers.some(trigger => trigger.contains(event.target))) closePanels();
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') closePanels();
  });
})();
