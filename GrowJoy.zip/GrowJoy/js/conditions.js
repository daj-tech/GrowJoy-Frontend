// Keep growing preferences when the user moves between steps.
const savedConditions = JSON.parse(localStorage.getItem('growjoyConditions') || '{}');
if (savedConditions.sunlight) document.getElementById('sunlight').value = savedConditions.sunlight;
if (savedConditions.soil) document.getElementById('soil').value = savedConditions.soil;
    document.querySelectorAll('[data-group]').forEach(group => {
      const previous = savedConditions[group.dataset.group];
      if (previous) {
        group.querySelectorAll('button[data-value]').forEach(option => {
          const selected = option.dataset.value === previous;
          option.classList.toggle('selected', selected);
          option.setAttribute('aria-pressed', String(selected));
        });
      }
      group.querySelectorAll('button[data-value]').forEach(button => {
        button.addEventListener('click', () => {
          group.querySelectorAll('button[data-value]').forEach(option => {
            option.classList.remove('selected');
            option.setAttribute('aria-pressed', 'false');
          });
          button.classList.add('selected');
          button.setAttribute('aria-pressed', 'true');
        });
      });
    });

    const toast = document.getElementById('toast');
    let toastTimer;
    function showToast(message) {
      toast.textContent = message;
      toast.classList.add('visible');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => toast.classList.remove('visible'), 3200);
    }

    document.getElementById('conditionsForm').addEventListener('submit', event => {
      event.preventDefault();
      const chosen = {};
      document.querySelectorAll('[data-group]').forEach(group => {
        const selected = group.querySelector('.selected');
        chosen[group.dataset.group] = selected ? selected.dataset.value : '';
      });
      chosen.sunlight = document.getElementById('sunlight').value;
      chosen.soil = document.getElementById('soil').value;
      const unselected = Object.entries(chosen).filter(([, value]) => !value);
      if (unselected.length) {
        showToast('Choose an option for each section to personalize your plant match.');
        return;
      }
      localStorage.setItem('growjoyConditions', JSON.stringify(chosen));
      window.location.href = '../recommendations/index.html';
    });

