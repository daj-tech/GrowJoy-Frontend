const cards = [...document.querySelectorAll('.plant-card')];
    const selectedPlantName = document.getElementById('selectedPlantName');
    const toast = document.getElementById('toast');
    let toastTimer;
    const knownPlants = ['Mint', 'Lemon Balm', 'Parsley'];
    const savedPlant = localStorage.getItem('growjoySelectedPlant');
    let selectedPlant = knownPlants.includes(savedPlant) ? savedPlant : 'Mint';

    function showToast(message) {
      toast.textContent = message;
      toast.classList.add('visible');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => toast.classList.remove('visible'), 3000);
    }

    function choosePlant(name) {
      selectedPlant = name;
      localStorage.setItem('growjoySelectedPlant', name);
      cards.forEach(card => {
        const selected = card.dataset.plant === name;
        card.classList.toggle('selected', selected);
        card.setAttribute('aria-checked', String(selected));
        const button = card.querySelector('.select-plant-button');
        button.classList.toggle('chosen', selected);
        button.querySelector('span').textContent = selected ? '✓' : '＋';
        const stamp = card.querySelector('.selected-stamp');
        if (stamp) stamp.classList.toggle('is-hidden', !selected);
      });
      selectedPlantName.textContent = name;
    }

    choosePlant(selectedPlant);
    const preferences = JSON.parse(localStorage.getItem('growjoyConditions') || '{}');
    const preferenceValues = document.querySelectorAll('.preference-item strong');
    const preferenceKeys = ['location', 'sunlight', 'space', 'experience', 'plantType'];
    preferenceValues.forEach((node, index) => {
      if (preferences[preferenceKeys[index]]) node.textContent = preferences[preferenceKeys[index]];
    });

    cards.forEach(card => {
      card.addEventListener('click', event => {
        if (event.target.closest('button')) return;
        choosePlant(card.dataset.plant);
      });
      card.addEventListener('keydown', event => {
        if ((event.key === 'Enter' || event.key === ' ') && !event.target.closest('button')) {
          event.preventDefault();
          choosePlant(card.dataset.plant);
        }
      });
      card.querySelector('.select-plant-button').addEventListener('click', () => {
        choosePlant(card.dataset.plant);
        showToast(`${card.dataset.plant} selected for your care plan.`);
      });
    });

    document.getElementById('createPlanButton').addEventListener('click', () => {
      window.location.href = '../activity/index.html';
    });
    document.getElementById('backButton').addEventListener('click', () => {
      window.location.href = '../conditions/index.html';
    });
    document.getElementById('editPreferences').addEventListener('click', () => {
      window.location.href = '../conditions/index.html';
    });
